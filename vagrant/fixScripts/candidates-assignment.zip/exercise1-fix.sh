#!/bin/bash
 sudo ip route del 208.86.224.90/32 
